#include<stdio.h>
#include<stdlib.h>

#define MAX 20
#define maxKlub 15

typedef struct ekipa{
	char klub[maxKlub];
	unsigned bodovi;
	int golRazlika;
}ekipa_st;

FILE* otvori_fajl(char*, char*, int);
void ucitaj_ekipe(FILE*, ekipa_st[], int*);
void razmeni(ekipa_st[], ekipa_st[]);
void sortiraj(FILE*, ekipa_st[], int);

int main(int brArg, char* arg[]) {
	ekipa_st ekipe[MAX];
 	int n = 0;

	if(brArg != 3) {
		printf("Greska prilikom poziva programa!\n");
		exit(1);
	}

	char* ulazna_datoteka = arg[1];
	char* izlazna_datoteka = arg[2];

	FILE* ulaz = otvori_fajl(ulazna_datoteka, "r", 2);
	FILE* izlaz = otvori_fajl(izlazna_datoteka, "w", 3);

	ucitaj_ekipe(ulaz, ekipe, &n);
	sortiraj(izlaz, ekipe, n);

	fclose(ulaz);
	fclose(izlaz);
	
	return 0;
}

FILE* otvori_fajl(char* naziv_fajla, char* rezim, int status_greske) {
	FILE* f = fopen(naziv_fajla, rezim);

	if(f == NULL) {
		printf("Greska prilikom otvaranja datoteke %s!\n", naziv_fajla);
		exit(status_greske);
	}
	return f;
}

void ucitaj_ekipe(FILE* ulaz, ekipa_st ekipe[], int* n) {
	while(fscanf(ulaz, "%s %u %d", ekipe[*n].klub, &ekipe[*n].bodovi, &ekipe[*n].golRazlika) != EOF) {
		(*n)++;
	}
}

void razmeni(ekipa_st* a, ekipa_st* b) {
	ekipa_st pom;

	pom = *a;
	*a = *b;
	*b = pom;
}

void sortiraj(FILE* izlaz, ekipa_st ekipe[], int n) {
	int i, j, k;

	for(i=n/2; i>0; i=i/2) {
		for(j=i; j<n; j++) {
			for(k=j-i; k>=0; k=k-i) {
				if(ekipe[k+i].bodovi < ekipe[k].bodovi) {
					break;
				}else if((ekipe[k+i].bodovi > ekipe[k].bodovi) || 
							(ekipe[k+i].bodovi == ekipe[k].bodovi && ekipe[k+i].golRazlika > ekipe[k].golRazlika)) {
					razmeni(&ekipe[k+i], &ekipe[k]);
					
				}
			}
		}
	}

	for(i=0; i<n; i++) {
		fprintf(izlaz, "%s %u %d\n", ekipe[i].klub, ekipe[i].bodovi, ekipe[i].golRazlika);
	}
}

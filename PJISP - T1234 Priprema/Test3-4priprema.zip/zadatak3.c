#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define MAX 50
#define maxIme 20
#define maxTip 30

typedef struct emisija{
	char ime[maxIme];
	float frekvencija;
	unsigned trajanje;
	char tip[maxTip];
}emisija_st;

FILE* otvori_fajl(char*, char*, int);
void ucitaj_emisije(FILE*, emisija_st[], int*);
void trajanje_sat(FILE*, emisija_st[], int);
void najkraca(emisija_st[], float, int);
void tip_trajanje(FILE*, emisija_st[], char*, int);

int main(int brArg, char* arg[]) {
	emisija_st emisije[MAX];
	int n = 0;

	if(brArg != 4) {
		printf("Greska prilikom poziva programa!\n");
		exit(1);
	}

	char* ulazna_datoteka = arg[1];
	char* izlazna_datoteka = arg[2];
	float frekvencija = atof(arg[3]);

	FILE* ulaz = otvori_fajl(ulazna_datoteka, "r", 2);
	FILE* izlaz = otvori_fajl(izlazna_datoteka, "w", 3);

	ucitaj_emisije(ulaz, emisije, &n);
	trajanje_sat(izlaz, emisije, n);
	najkraca(emisije, frekvencija, n);

	char tip[maxTip];

	printf("Unesite tip emisije: ");
	scanf("%s", tip);

	char tip_txt[maxTip];

	strcpy(tip_txt, tip);
	strcat(tip_txt, ".txt");

	FILE* izlaz2 = otvori_fajl(tip_txt, "w", 4);

	tip_trajanje(izlaz2, emisije, tip, n);

	fclose(ulaz);
	fclose(izlaz);
	fclose(izlaz2);

	return 0;
}

FILE* otvori_fajl(char* naziv_fajla, char* rezim, int status_greske) {
	FILE* f = fopen(naziv_fajla, rezim);

	if(f == NULL) {
		printf("Greska prilikom otvaranja datoteke %s!\n", naziv_fajla);
		exit(status_greske);
	}
	return f;
}

void ucitaj_emisije(FILE* ulaz, emisija_st emisije[], int* n) {
	while(fscanf(ulaz, "%s %f %u %s", emisije[*n].ime, &emisije[*n].frekvencija, &emisije[*n].trajanje, emisije[*n].tip) != EOF) {
		(*n)++;
	}
}

void trajanje_sat(FILE* izlaz, emisija_st emisije[], int n) {
	int i;

	for(i=0;i<n;i++) {
		fprintf(izlaz, "%s %.1f %.2f %s\n", emisije[i].ime, emisije[i].frekvencija, (float)emisije[i].trajanje/60.0, emisije[i].tip);
	}
}

void najkraca(emisija_st emisije[], float frekvencija, int n) {
	int i, brojac = 0;
	int pom[MAX];
	unsigned minTrajanje;

	for(i=0;i<n;i++) {
		if(emisije[i].frekvencija > frekvencija) {
			pom[brojac] = i;
			brojac++;
		}
	}

	minTrajanje = emisije[pom[0]].trajanje;

	for(i=1;i<brojac;i++) {
		if(emisije[pom[i]].trajanje < minTrajanje) {
			minTrajanje = emisije[pom[i]].trajanje;
		}
	}

	for(i=0;i<brojac;i++) {
		if(emisije[pom[i]].trajanje == minTrajanje) {
			printf("Najkraca emisija na frekvenciji vecoj od %.1f je:\n", frekvencija);
			printf("%s %.1f %u %s\n\n", emisije[pom[i]].ime, emisije[pom[i]].frekvencija, emisije[pom[i]].trajanje, emisije[pom[i]].tip);
		}
	}
}

void tip_trajanje(FILE* izlaz2, emisija_st emisije[], char* tip, int n) {
	int i, brojac;
	unsigned suma = 0;
	float prosek;

	for(i=0;i<n;i++) {
		if(strcmp(emisije[i].tip, tip) == 0) {
			suma += emisije[i].trajanje;
			brojac++;
		}
	}

	prosek = (float)suma/(float)brojac;

	fprintf(izlaz2, "%.2f", prosek);
}

#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define MAX 50
#define maxIP 20
#define maxZanimanje 30

typedef struct radnik{
	char ime[maxIP];
	char prezime[maxIP];
	float plata;
	char zanimanje[maxZanimanje];
}radnik_st;

FILE* otvori_fajl(char*, char*, int);
void ucitaj_radnike(FILE*, radnik_st[], int*);
void usteda(radnik_st[], float*, int);
void nova_plata(FILE*, radnik_st[], float*, int);
void plata_zanimanje(FILE*, radnik_st[], char*, int);

int main(int brArg, char* arg[]) {
	radnik_st radnici[MAX];
	int n = 0;
	float novaPlata[MAX];

	if(brArg != 3) {
		printf("Greska prilikom poziva programa!\n");
		exit(1);
	}

	char* ulazna_datoteka = arg[1];
	char* izlazna_datoteka = arg[2];

	FILE* ulaz = otvori_fajl(ulazna_datoteka, "r", 2);
	FILE* izlaz = otvori_fajl(izlazna_datoteka, "w", 3);

	ucitaj_radnike(ulaz, radnici, &n);
	usteda(radnici, novaPlata, n);
	nova_plata(izlaz, radnici, novaPlata, n);

	char zanimanje[maxZanimanje];

	printf("Unesite zanimanje: ");
	scanf("%s", zanimanje);

	char zanimanje_txt[maxZanimanje];

	strcpy(zanimanje_txt, zanimanje);
	strcat(zanimanje_txt, ".txt");

	FILE* izlaz2 = otvori_fajl(zanimanje_txt, "w", 4);

	plata_zanimanje(izlaz2, radnici, zanimanje, n);

	fclose(ulaz);
	fclose(izlaz);
	fclose(izlaz2);

	return 0;
}

FILE* otvori_fajl(char* naziv_fajla, char* rezim, int status_greske) {
	FILE* f = fopen(naziv_fajla, rezim);

	if(f == NULL) {
		printf("Greska prilikom otvaranja datoteke %s!\n", naziv_fajla);
		exit(status_greske);
	}
	return f;
}

void ucitaj_radnike(FILE* ulaz, radnik_st radnici[], int* n) {
	while(fscanf(ulaz, "%s %s %f %s", radnici[*n].ime, radnici[*n].prezime, &radnici[*n].plata, radnici[*n].zanimanje) != EOF) {
		(*n)++;
	}
}

void usteda(radnik_st radnici[], float* novaPlata, int n) {
	int i;
	float usteda = 0.0;

	for(i=0;i<n;i++) {
		novaPlata[i] = radnici[i].plata*0.9;
	}

	for(i=0;i<n;i++) {
		usteda += (radnici[i].plata - novaPlata[i])*12;
	}

	printf("Usteda na nivou svih radnika za godinu dana je %.2f\n\n", usteda);
}

void nova_plata(FILE* izlaz, radnik_st radnici[], float* novaPlata, int n) {
	int i;

	for(i=0;i<n;i++) {
		radnici[i].plata = novaPlata[i];
	}

	for(i=0;i<n;i++) {
		fprintf(izlaz, "%s %s %.2f %s\n", radnici[i].ime, radnici[i].prezime, radnici[i].plata, radnici[i].zanimanje);
	}
}

void plata_zanimanje(FILE* izlaz2, radnik_st radnici[], char* zanimanje, int n) {
	int i, brojac = 0;
	float suma = 0.0, prosek;

	for(i=0;i<n;i++) {
		if(strcmp(radnici[i].zanimanje, zanimanje) == 0) {
			suma += radnici[i].plata;
			brojac++;
		}
	}

	prosek = suma/(float)brojac;

	fprintf(izlaz2, "%.2f", prosek);
}

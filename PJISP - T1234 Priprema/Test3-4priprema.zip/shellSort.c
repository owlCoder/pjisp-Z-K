#include<stdio.h>

int main() {
	int niz[30];
	int i, j, k, pom, n;

	printf("Unesite broj elemenata niza: ");
	scanf("%d", &n);

	for(k=0;k<n;k++) {
		printf("niz[%d]= ", k+1);
		scanf("%d", &niz[k]);
	}

	for(i = n/2;i>0;i = i/2) {
		for(j=i;j<n;j++) {
			for(k=j-i;k>=0;k = k-i) {
				if(niz[k+i] >= niz[k]) {
					break;
				}else {
					pom = niz[k];
					niz[k] = niz[k+i];
					niz[k+i] = pom;
				}
			}
		}
	}

	for(k=0;k<n;k++) {
		printf("%d\t", niz[k]);
	}

	printf("\n\n");

	return 0;
}

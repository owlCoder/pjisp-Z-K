#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define MAX 50
#define maxIP 20
#define maxOblast 30

typedef struct naucnik{
	char ime[maxIP];
	char prezime[maxIP];
	unsigned broj_radova;
	char oblast[maxOblast];
}naucnik_st;

FILE* otvori_fajl(char*, char*, int);
void ucitaj_naucnike(FILE*, naucnik_st[], int*);
void brojRadova(FILE*, naucnik_st[], unsigned, int);
void prosecno_prezime(naucnik_st[], int);
void oblast_radovi(FILE*, naucnik_st[], char*, int);

int main(int brArg, char* arg[]) {
	naucnik_st naucnici[MAX];
	int n = 0;

	if(brArg != 4) {
		printf("Greska prilikom poziva programa!\n");
		exit(1);
	}

	char* ulazna_datoteka = arg[1];
	char* izlazna_datoteka = arg[2];
	unsigned broj_radova = (unsigned)(atoi(arg[3]));

	FILE* ulaz = otvori_fajl(ulazna_datoteka, "r", 2);
	FILE* izlaz = otvori_fajl(izlazna_datoteka, "w", 3);

	ucitaj_naucnike(ulaz, naucnici, &n);
	brojRadova(izlaz, naucnici, broj_radova, n);
	prosecno_prezime(naucnici, n);

	char oblast[maxOblast];
	
	printf("Unesite naucnu oblast: ");
	scanf("%s", oblast);

	char oblast_txt[maxOblast];

	strcpy(oblast_txt, oblast);
	strcat(oblast_txt, ".txt");

	FILE* izlaz2 = otvori_fajl(oblast_txt, "w", 4);

	oblast_radovi(izlaz2, naucnici, oblast, n);

	fclose(ulaz);
	fclose(izlaz);
	fclose(izlaz2);

	return 0;
}

FILE* otvori_fajl(char* naziv_fajla, char* rezim, int status_greske) {
	FILE* f = fopen(naziv_fajla, rezim);

	if(f == NULL) {
		printf("Greska prilikom otvaranja datoteke %s!\n", naziv_fajla);
		exit(status_greske);
	}
	return f;
}

void ucitaj_naucnike(FILE* ulaz, naucnik_st naucnici[], int* n) {
	while(fscanf(ulaz, "%s %s %u %s", naucnici[*n].ime, naucnici[*n].prezime, &naucnici[*n].broj_radova, naucnici[*n].oblast) != EOF) {
		(*n)++;
	}
}

void brojRadova(FILE* izlaz, naucnik_st naucnici[], unsigned broj_radova, int n) {
	int i;

	for(i=0;i<n;i++) {
		if(naucnici[i].broj_radova > broj_radova) {
			fprintf(izlaz, "%s %s %u %s\n", naucnici[i].ime, naucnici[i].prezime, naucnici[i].broj_radova, naucnici[i].oblast);
		}
	}
}

void prosecno_prezime(naucnik_st naucnici[], int n) {
	int i, j, suma, brojac, prezime;

	suma = strlen(naucnici[0].prezime);
	brojac = 1;

	for(i=1;i<n;i++) {
		prezime = 0;
		for(j=0;j<i;j++) {
			if(strcmp(naucnici[i].prezime, naucnici[j].prezime) == 0) {
				prezime = 1;
			}
		}
		if(prezime == 0) {
			suma += strlen(naucnici[i].prezime);
			brojac++;
		}
	}

	printf("Prosecna duzina prezimena je %.2f\n", (float)suma/(float)brojac);
}

void oblast_radovi(FILE* izlaz2, naucnik_st naucnici[], char* oblast, int n) {
	int i;
	unsigned suma = 0;

	for(i=0;i<n;i++) {
		if(strcmp(naucnici[i].oblast, oblast) == 0) {
			suma += naucnici[i].broj_radova;
		}
	}

	fprintf(izlaz2, "%u", suma);
}

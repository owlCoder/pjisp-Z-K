#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define MAX 50
#define maxIP 21
#define maxPredmet 11

typedef struct student{
	char ime[maxIP];
	char prezime[maxIP];
	unsigned bodovi1;
	unsigned bodovi2;
	char predmet[maxPredmet];
}student_st;

FILE* otvori_fajl(char*, char*, int);
void ucitaj_studente(FILE*, student_st[], int*);
void ukupno_poena(FILE*, student_st[], int);
void apsolutna_razlika(student_st[], int);
void predmet_bodovi(FILE*, student_st[], char*, int);

int main(int brArg, char* arg[]) {
	student_st studenti[MAX];
	int n = 0;

	if(brArg != 3) {
		printf("Greska prilikom poziva programa!\n");
		exit(1);
	}

	char* ulazna_datoteka = arg[1];
	char* izlazna_datoteka = arg[2];

	FILE* ulaz = otvori_fajl(ulazna_datoteka, "r", 2);
	FILE* izlaz = otvori_fajl(izlazna_datoteka, "w", 3);

	ucitaj_studente(ulaz, studenti, &n);
	ukupno_poena(izlaz, studenti, n);
	apsolutna_razlika(studenti, n);

	char predmet[maxPredmet];

	printf("Unesite predmet: ");
	scanf("%s", predmet);

	char predmet_txt[maxPredmet];

	strcpy(predmet_txt, predmet);
	strcat(predmet_txt, ".txt");

	FILE* izlaz2 = otvori_fajl(predmet_txt, "w", 4);

	predmet_bodovi(izlaz2, studenti, predmet, n);

	fclose(ulaz);
	fclose(izlaz);
	fclose(izlaz2);

	return 0;
}

FILE* otvori_fajl(char* naziv_fajla, char* rezim, int status_greske) {
	FILE* f = fopen(naziv_fajla, rezim);

	if(f == NULL) {
		printf("Greska prilikom otvaranja datoteke %s!\n", naziv_fajla);
		exit(status_greske);
	}
	return f;
}

void ucitaj_studente(FILE* ulaz, student_st studenti[], int* n) {
	while(fscanf(ulaz, "%s %s %u %u %s", studenti[*n].ime, studenti[*n].prezime, 
						&studenti[*n].bodovi1, &studenti[*n].bodovi2, studenti[*n].predmet) != EOF) {
		(*n)++;
	}
}

void ukupno_poena(FILE* izlaz, student_st studenti[], int n) {
	int i;

	for(i=0;i<n;i++) {
		fprintf(izlaz, "%s %s %u %u %s %u\n", studenti[i].ime, studenti[i].prezime, studenti[i].bodovi1, 
					studenti[i].bodovi2, studenti[i].predmet, studenti[i].bodovi1 + studenti[i].bodovi2);
	}
}

void apsolutna_razlika(student_st studenti[], int n) {
	int i, maxRazlika;
	int razlika[MAX];

	for(i=0;i<n;i++) {
		razlika[i] = abs(studenti[i].bodovi1 - studenti[i].bodovi2);
	}

	maxRazlika = razlika[0];

	for(i=1;i<n;i++) {
		if(razlika[i] > maxRazlika) {
			maxRazlika = razlika[i];
		}
	}

	for(i=0;i<n;i++) {
		if(razlika[i] == maxRazlika) {
			printf("%s %s %u %u %s\n", studenti[i].ime, studenti[i].prezime, studenti[i].bodovi1, studenti[i].bodovi2, studenti[i].predmet);
		}
	}
}

void predmet_bodovi(FILE* izlaz, student_st studenti[], char* predmet, int n) {
	int i, brojac = 0;

	for(i=0;i<n;i++) {
		if((strcmp(studenti[i].predmet, predmet) == 0) && (studenti[i].bodovi1 + studenti[i].bodovi2) >= 30) {
			brojac++;
		}
	}

	fprintf(izlaz, "%d", brojac);
}
